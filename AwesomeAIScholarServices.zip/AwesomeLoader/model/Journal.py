class Journal:
    def __init__(self):
        self.Journal_Name = None
        self.Phone_Number = None
        self.Address = None