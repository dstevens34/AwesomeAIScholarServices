class Paper:
    def __init__(self):
        self.Title = None
        self.abstract = None
        self.Print_ISSN = None
        self.Online_ISSN = None
        self.Language = None
        self.PageStart = None
        self.PageEnd = None
        self.DOI = None