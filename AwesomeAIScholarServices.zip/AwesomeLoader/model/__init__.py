from Paper import Paper
from Journal import Journal
from Author import Author
from Journal_Paper import Journal_Paper
from Journal_Publication import Journal_Publication
