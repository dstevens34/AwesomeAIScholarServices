class Journal_Paper:
    def __init__(self):
        self.Journal_Index = None
        self.Paper_Index = None
        self.Journal_ID = None
        self.URL = None
