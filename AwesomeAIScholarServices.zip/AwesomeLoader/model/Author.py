class Author:
    def __init__(self):
        self.First_Name = None
        self.Last_Name = None