class Journal_Publication:
    def __init__(self):
        self.Publication_Date = None
        self.Volume = None