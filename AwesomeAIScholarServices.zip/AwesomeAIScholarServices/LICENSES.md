All libraries and frameworks are open-source and used in accordance to their respective licenses.

Each library is listed below, along with a link to NPM for more information:

Node.js - https://nodejs.org/en/

angular - https://www.npmjs.com/package/angular
angular-animate - https://www.npmjs.com/package/angular-animate
angular-ui-bootstrap - https://www.npmjs.com/package/angular-ui-bootstrap
angular-ui-router - https://www.npmjs.com/package/angular-ui-router
body-parser - https://www.npmjs.com/package/body-parser
bootstrap - https://www.npmjs.com/package/bootstrap
connect-flash - https://www.npmjs.com/package/connect-flash
cookie-parser - https://www.npmjs.com/package/cookie-parser
ejs - https://www.npmjs.com/package/ejs
express - https://www.npmjs.com/package/express
express-session - https://www.npmjs.com/package/express-session
gulp - https://www.npmjs.com/package/gulp
gulp-angular-templatecache - https://www.npmjs.com/package/gulp-angular-templatecache
gulp-concat - https://www.npmjs.com/package/gulp-concat
gulp-connect - https://www.npmjs.com/package/gulp-connect
gulp-sourcemaps - https://www.npmjs.com/package/gulp-sourcemaps
gulp-watch - https://www.npmjs.com/package/gulp-watch
lodash - https://www.npmjs.com/package/lodash
morgan - https://www.npmjs.com/package/morgan
mysql - https://www.npmjs.com/package/mysql
passport - https://www.npmjs.com/package/passport
passport-google-oauth - https://www.npmjs.com/package/passport-google-oauth 