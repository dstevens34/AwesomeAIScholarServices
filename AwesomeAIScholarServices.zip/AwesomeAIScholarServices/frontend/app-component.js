angular.module('awesome')
    .component('awesome', {
        templateUrl: 'app.html',
        controller: 'AwesomeController'
    });