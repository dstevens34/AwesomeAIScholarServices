angular.module('awesome')
    .component('awesomeSaved', {
        templateUrl: 'saved.html',
        controller: 'SavedController'
    });