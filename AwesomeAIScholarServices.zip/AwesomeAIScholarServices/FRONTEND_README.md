To run frontend:

1. `cd frontend`
2. `npm install`

To build:
`gulp`

To develop:
`gulp dev`